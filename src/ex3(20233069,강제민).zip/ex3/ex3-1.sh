#!/bin/bash

read -p "출력할 횟수를 입력하세요: " num

for ((i = 1; i <= num; i++)); do
    echo "Hello, World!"
done

