#!/bin/bash

# 사용자로부터 팀원의 이름을 입력받음
read -p "팀원의 이름을 입력하세요: " name

# 사용자로부터 팀원의 생일 또는 전화번호를 입력받음
read -p "팀원의 생일 또는 전화번호를 입력하세요: " info

# 이름과 정보를 DB.txt 파일에 추가
echo "$name: $info" >> DB.txt

# 추가 완료 메시지 출력
echo "정보가 DB.txt 파일에 추가되었습니다."

