#!/bin/bash

read -p "리눅스가 재미있나요? (Yes/No): " response

case "$response" in
    [Yy]*)
        echo "Yes"
        ;;
    [Nn]*)
        echo "No"
        ;;
    *)
        echo "올바른 대답을 입력하세요. 'Yes' 또는 'No'로 대답하세요."
        ;;
esac

