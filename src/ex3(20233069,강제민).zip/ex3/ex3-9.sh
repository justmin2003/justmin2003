#!/bin/sh

echo $(grep $1 DB.txt)

exit 0

